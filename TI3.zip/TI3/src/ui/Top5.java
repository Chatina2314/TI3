package ui;

import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.NodeScore;
import model.ScoreTree;

public class Top5 extends Stage{
	
	private TableView<NodeScore> topTF;
	private TextField deleteTF;
	private Button deleteBT, backBT, searchBT;
	private Label searchL;
	
	private ScoreTree tree;

	public Top5() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Top5.fxml"));
            Parent parent = loader.load();

            topTF = (TableView) loader.getNamespace().get("topTF");
            deleteBT = (Button) loader.getNamespace().get("deleteBT");
            backBT = (Button) loader.getNamespace().get("backBT");
            searchBT = (Button) loader.getNamespace().get("searchBT");
            deleteTF = (TextField) loader.getNamespace().get("deleteTF");
            searchL = (Label) loader.getNamespace().get("searchL");
            
            tree = Main.tree;

            TableColumn<NodeScore, String> nameCol = new TableColumn<>("Name");
            TableColumn<NodeScore, Integer> scoreCol = new TableColumn<>("Score");
            


            nameCol.setCellValueFactory(new PropertyValueFactory<>("player"));
            scoreCol.setCellValueFactory(new PropertyValueFactory<>("score"));
            
            topTF.getColumns().clear();
            tree.getData().clear();
            
            tree.triggerMakeArray();
            
            topTF.getColumns().addAll(nameCol, scoreCol);
            topTF.setItems(tree.getData());
			
            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
            
            System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void init() {
		deleteBT.setOnAction(event->{
			String name=deleteTF.getText();
			tree.triggerDelete(name);
			tree.getData().clear();
			tree.triggerMakeArray();
			topTF.refresh();
		});
		backBT.setOnAction(e->{
			Log badEnglitch=new Log();
			badEnglitch.show();
			tree.getData().clear();
			this.close();
		});
		
		searchBT.setOnAction(e->{
			String message=tree.triggerSearch(deleteTF.getText());
			System.out.println(message);
			searchL.setText(message);
		});
		
	}
}
