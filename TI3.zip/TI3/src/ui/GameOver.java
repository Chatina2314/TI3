package ui;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.ScoreTree;

public class GameOver extends Stage{
	
	private Label gameoverLabel, label1, scoreLB;
	private Button retryBT;
	private int score;
	
	public GameOver(int score, String name) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("GameOver.fxml"));
			Parent root = loader.load();
			
			gameoverLabel = (Label) loader.getNamespace().get("gameoverLabel");
			label1 = (Label) loader.getNamespace().get("label1");
			scoreLB = (Label) loader.getNamespace().get("scoreLB");
			retryBT = (Button) loader.getNamespace().get("retryBT");
			
			scoreLB.setText(""+score);
			
			Main.tree.add(score, name);
			Main.tree.triggerInOrder();
			Main.tree.saveList();
			
			Scene scene = new Scene(root, 600,400);
			setScene(scene);
			
			init();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void init() {
		
		retryBT.setOnAction(event->{
			Log badEnglitch=new Log();
			badEnglitch.show();
			this.close();
		});
		
	}
}
