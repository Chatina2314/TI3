package ui;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class GameOver extends Stage{
	
	private Label gameoverLabel;
	
	public GameOver() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("GameOver.fxml"));
			Parent root = loader.load();
			
			gameoverLabel = (Label) loader.getNamespace().get("gameoverLabel");
			
			Scene scene = new Scene(root, 600,400);
			setScene(scene);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
