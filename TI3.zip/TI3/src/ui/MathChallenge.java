package ui;

import java.io.IOException;

import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.Contador;

public class MathChallenge extends Stage{
	private Button giveUpBtn;
	private Button nextBtn;
	private Label counter;
	private Label operation;
	
	private Contador counterThread;
	
	public MathChallenge() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("MathChallenge.fxml"));
			Parent root = loader.load();
			
			giveUpBtn = (Button) loader.getNamespace().get("giveUpBtn");
			nextBtn = (Button) loader.getNamespace().get("nextBtn");
			counter = (Label) loader.getNamespace().get("counter");
			operation = (Label) loader.getNamespace().get("operation");
			
			Scene scene = new Scene(root, 600,400);
			setScene(scene);
			
			init();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void init() {
		giveUpBtn.setOnAction(event->{
			GameOver gameover = new GameOver();
			gameover.show();
		});
		
		counterThread=new Contador(this);
		counterThread.start();
	}
	
	public void counterChange(int c) {
		Platform.runLater(()->{
			if(c>0) {
				counter.setText(""+c);
			}else {
				GameOver gameover = new GameOver();
				gameover.show();
				this.close();
			}
		});
	}
}
