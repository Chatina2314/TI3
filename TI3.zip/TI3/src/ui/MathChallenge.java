package ui;

import java.io.IOException;

import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.Contador;

public class MathChallenge extends Stage{
	private Button giveUpBtn;
	private Button nextBtn, nextBtn1, nextBtn2, nextBtn3;
	private Label counter;
	private Label operation, pointsL, nameL;
	
	private Contador counterThread;
	
	private String name;
	private int score;
	
	public MathChallenge(String name) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("MathChallenge.fxml"));
			Parent root = loader.load();
			
			giveUpBtn = (Button) loader.getNamespace().get("giveUpBtn");
			nextBtn = (Button) loader.getNamespace().get("nextBtn");
			nextBtn1 = (Button) loader.getNamespace().get("nextBtn1");
			nextBtn2 = (Button) loader.getNamespace().get("nextBtn2");
			nextBtn3 = (Button) loader.getNamespace().get("nextBtn3");
			counter = (Label) loader.getNamespace().get("counter");
			operation = (Label) loader.getNamespace().get("operation");
			pointsL = (Label) loader.getNamespace().get("pointsL");
			nameL = (Label) loader.getNamespace().get("nameL");
			
			nameL.setText(name);
			this.name=name;
			
			Scene scene = new Scene(root, 600,400);
			setScene(scene);
			

			init();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	private void init() {
		giveUpBtn.setOnAction(event->{
			GameOver gameover = new GameOver(score, name);
			counterThread.stop();
			gameover.show();
			this.close();
		});
		createQuestion();
		counterThread=new Contador(this);
		counterThread.start();
		System.out.println(name);
	}
	public void setName(String name){
		this.name=name;
	}
	public void createQuestion(){
		int res =0;
		int right=(int)(Math.random()*4)+1;
		int fakeRes1=0;
		int fakeRes2=0;
		int fakeRes3=0;
		int puntos=Integer.parseInt(pointsL.getText());
		String pointsT="";
		res=createMath();
		fakeRes1=res+(int)(Math.random()*16)+1;
		fakeRes2=res-(int)(Math.random()*40)+1;
		fakeRes3=(int)(Math.random()*999)+1;
		System.out.println(res);
		switch(right) {
			case 1:
				nextBtn.setText(""+res);
				nextBtn1.setText(""+fakeRes1);
				nextBtn2.setText(""+fakeRes2);
				nextBtn3.setText(""+fakeRes3);
					
				nextBtn.setOnAction(event->{
					addPoints(puntos);
					createQuestion();
				});
				nextBtn1.setOnAction(event->{
					redusePoints(puntos);
					createQuestion();
				});
				nextBtn2.setOnAction(event->{
					redusePoints(puntos);
					createQuestion();
				});
				nextBtn3.setOnAction(event->{
					redusePoints(puntos);
					createQuestion();
				});
			break;
			case 2:
				nextBtn2.setText(""+fakeRes1);
				nextBtn.setText(""+fakeRes2);
				nextBtn3.setText(""+fakeRes3);
				nextBtn1.setText(""+res);
				
				nextBtn1.setOnAction(event->{
					addPoints(puntos);
					createQuestion();
				});
				nextBtn.setOnAction(event->{
					redusePoints(puntos);
				});
				nextBtn2.setOnAction(event->{
					redusePoints(puntos);
				});
				nextBtn3.setOnAction(event->{
					redusePoints(puntos);
				});
			break;
			case 3:
				nextBtn2.setText(""+res);
				nextBtn3.setText(""+fakeRes1);
				nextBtn.setText(""+fakeRes2);
				nextBtn1.setText(""+fakeRes3);
				
				nextBtn2.setOnAction(event->{
					addPoints(puntos);
					createQuestion();
				});
				nextBtn.setOnAction(event->{
					redusePoints(puntos);
				});
				nextBtn1.setOnAction(event->{
					redusePoints(puntos);
				});
				nextBtn3.setOnAction(event->{
					redusePoints(puntos);
				});
				
			break;
			case 4:
				nextBtn3.setText(""+res);
				nextBtn2.setText(""+fakeRes1);
				nextBtn.setText(""+fakeRes2);
				nextBtn1.setText(""+fakeRes3);
				
				nextBtn3.setOnAction(event->{
					addPoints(puntos);
					createQuestion();
				});
				
				nextBtn.setOnAction(event->{
					redusePoints(puntos);
				});
				nextBtn2.setOnAction(event->{
					redusePoints(puntos);
				});
				nextBtn1.setOnAction(event->{
					redusePoints(puntos);
				});
			break;
		}
	}
	
	private void addPoints(int puntos) {
		puntos+=10;
		score+=10;
		pointsL.setText(""+puntos);
	}
	private void redusePoints(int puntos) {
		puntos-=10;
		score-=10;
		pointsL.setText(""+puntos);
		createQuestion();
	}

	public int createMath() {
		int res =0;
		int op=(int)(Math.random()*4)+1;
		int num1=0;
		int num2=0;
		switch(op) {
		case 1:
			//suma
			res=(int)(Math.random()*99)+1;
			num1= 
			num2= res-num1;
			System.out.println(num1 + "+" + num2 + "=" + res);
			operation.setText(num1 + "+" + num2);
		break;
		case 2:
			num2=(int)(Math.random()*99)+1;
			num1= (int)(Math.random()*99)+1;
			res= num1-num2;
			System.out.println(num1 + "-" + num2 + "=" + res);
			operation.setText(num1 + "-" + num2);
		break;
		case 3:
			//multiplicacino
			num2=(int)(Math.random()*99)+1;
			num1= (int)(Math.random()*99)+1;
			res= num2*num1;
			System.out.println(num1 + "*" + num2 + "=" + res);
			operation.setText(num1 + "*" + num2);
		break;
		case 4:
			//division
			boolean cat=true;
			while(cat) {
				num2=(int)(Math.random()*99)+1;
				num1= (int)(Math.random()*99)+1;
				
				if(num1%num2==0 && num2>3) {
					res= num1/num2;
					cat=false;
				}
				
			}
			System.out.println(num1 + "/" + num2 + "=" + res);
			operation.setText(num1 + "/" + num2);
			
		break;
		
		}
		
		return  res;
	}

	public void counterChange(int c) {
		Platform.runLater(()->{
			if(c>0) {
				counter.setText(""+c);
			}else {
				GameOver gameover = new GameOver(score, nameL.getText());
				gameover.show();
				this.close();
			}
		});
	}
}
