package ui;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Log extends Stage{
	
	TextField userNameTF;
	
	Button okBT, topBT;
	String name="";
	
	MathChallenge math;
	
	public Log() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Log.fxml"));
			Parent root = loader.load();
			
			userNameTF = (TextField) loader.getNamespace().get("userNameTF");
			okBT = (Button) loader.getNamespace().get("okBT");
			topBT = (Button) loader.getNamespace().get("topBT");
			
			Scene scene = new Scene(root, 600,400);
			setScene(scene);
			
			init();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void init() {
		okBT.setOnAction(event->{
			
			name=userNameTF.getText();

			LoginScreen load=new LoginScreen(name);
			load.show();
			this.close();
		});
		
		topBT.setOnAction(event->{

			Top5 load=new Top5();
			load.show();
			this.close();
		});
		
	}

}
