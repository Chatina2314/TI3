package ui;

import javafx.application.Application;
import javafx.stage.Stage;
import model.ScoreTree;

public class Main extends Application {
	
	public static ScoreTree tree=new ScoreTree();

	public static void main(String[] args) {
		launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		Log badEnglitch=new Log();
		badEnglitch.show();
		
	}
	

}
