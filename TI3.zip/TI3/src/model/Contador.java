package model;

import ui.MathChallenge;

public class Contador extends Thread {
	
	private MathChallenge math;
	public Contador(MathChallenge m) {
		this.math=m;
	}
	public void run() {
		int maxC=30;
		int c=maxC;
		try {
			for(int i=0;i<maxC;i++) {
				Thread.sleep(1000);
				c--;
				math.counterChange(c);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
