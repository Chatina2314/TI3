package model;

public class NameTree {

	private NodeName root;

}
