package model;

public class ScoreTree {
	
	private NodeScore root;
}
