package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ScoreTree {
	
private NodeScore root;
private ObservableList<NodeScore> players;
private ObservableList<NodeScore> top5 = FXCollections.observableArrayList();
	
	public ScoreTree() {
		players=FXCollections.observableArrayList();
	}
	
	public void inOrder(NodeScore node) {
		if(node==null) {
			return;
		}
		
		inOrder(node.getLeft());
		System.out.println(node.getPlayer()+" "+node.getKey());
		inOrder(node.getRight());
	}
	
	public void triggerInOrder() {
		inOrder(root);
	}
	
	public void saveList() {
		try {
			
			ObjectOutputStream save = new ObjectOutputStream(new FileOutputStream("D:\\Desktop\\programas 2\\inte 3\\docs\\saveData.txt"));
			save.writeObject(players);
			save.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void loadList() {
		try {
			
			ObjectInputStream load = new ObjectInputStream(new FileInputStream("inte 3\\docs\\saveData.txt"));
			ObservableList<NodeScore> loaded =(ObservableList<NodeScore>) load.readObject();
			load.close();
			
			for(int i=0; i<loaded.size(); i++) {
				add(loaded.get(i).getScore(), loaded.get(i).getPlayer());
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public NodeScore inOrder2(NodeScore node) {
		if(node==null) {
			return null;
		}
		
		inOrder(node.getLeft());
		inOrder(node.getRight());
		return node;
	}
	
	

	public void add(int score, String name) {
		NodeScore found = triggerSearch2(name);
		if(root == null) {
			root= new NodeScore(score, name);
		}else {
			if(found==null) {
				root.insert(score, name);
			}else {
				if(score>found.getScore()) {
					found.setScore(score);
				}else {
					return;
				}
			}
		}
		
	}
	
	public void makeArray(NodeScore node) {
		if(node==null) {
			return;
		}
		
		makeArray(node.getLeft());
		System.out.println(node.getPlayer()+" "+node.getKey());
		players.add(node);
		makeArray(node.getRight());
	}
	
	public void triggerMakeArray() {
		makeArray(root);
	}
	
	public ObservableList<NodeScore> getData(){
		//ObservableList<NodeScore> top5 = FXCollections.observableArrayList();
		top5.clear();
		if(players.size()>=5) {
			for(int i=0; i<5;i++) {
				if(players.get(i)!=null) {
				top5.add(players.get(i));
				}
			}
		}else {
			for(int i=0; i<players.size();i++) {
				if(players.get(i)!=null) {
				top5.add(players.get(i));
				}
			}
		}
		return top5;
	}
	
	public String search(String j, NodeScore node) {
		String message="no hay gente agregada";
		if(node==null) {
			return message;
		}if(node.getPlayer().equalsIgnoreCase(j)) {
			message= "name: "+ node.getPlayer()+"\nScore: "+node.getScore();
			return message;
		}
		if(node.getScore()>root.getScore()) {
			return search(j, node.getLeft());
		}
		if(node.getScore()>root.getScore()) {
			return search(j, node.getRight());
		}
		return message;
	}
	
	public String triggerSearch(String j) {
		String a= search(j, root);
		return a;
	}
	public NodeScore search2(String j, NodeScore node) {
		String message="no hay gente agregada";
		if(node==null) {
			return null;
		}if(node.getPlayer().equalsIgnoreCase(j)) {
			message= "nombre: "+ node.getPlayer()+"\nphone: "+node.getScore();
			return node;
		}
		if(node.getScore()>root.getScore()) {
			return search2(j, node.getLeft());
		}
		if(node.getScore()>root.getScore()) {
			return search2(j, node.getRight());
		}
		return null;
	}
	
	public NodeScore triggerSearch2(String j) {
		NodeScore a= search2(j, root);
		return a;
	}
	
	public void delete(String j, NodeScore node) {
		if(node==null) {
			return;
		}if(node.getPlayer().equalsIgnoreCase(j)) {
			
			if(node.getRight()!=null && node.getLeft()!=null) {
			
				node.getLeft().setright(node.getRight());
				node.getRight().setright(node.getLeft());
				triggerInOrder();
				return;
			}else if(node.getLeft()==null && node.getRight()!=null) {
				node.getRight().setright(node.getLeft());
				node=null;
				triggerInOrder();
			}else if(node.getLeft()!=null && node.getRight()==null) {
				node.getLeft().setright(node.getRight());
				node=null;
				triggerInOrder();
			}
		}
		if(node.getScore()>0) {
			delete(j, node.getLeft());
		}
		if(node.getScore()<0) {
			delete(j, node.getRight());
		}
		return ;
	}
	
	/*public NodeScore delete(String j, NodeScore current) {
		 if(current.getPlayer().equalsIgnoreCase(j)) {
			 if(current.getLeft()==null&&
					 current.getRight()==null) {
				 return null;
			 }else if(current.getLeft()!=null&&
					 current.getRight()!=null) {
				 NodeScore succesor = getMin(current.getRight());
				 NodeScore newRightTree = delete(succesor.getPlayer(), current.getRight());
				 succesor.setLeft(current.getLeft());
				 succesor.setright(newRightTree);
			 }else if(current.getLeft()!=null) {
				 return current.getLeft();
			 }else {
				 return current.getRight();
			 }
		 }else if (current.getScore()>0){
			NodeScore newLeftTree = delete(j, current.getLeft());
			current.setLeft(newLeftTree);
		 }else {
			 NodeScore newRightTree = delete(j, current.getRight());
			 current.setright(newRightTree);
		 }
		 
		 return null;
	}
	*/
	
	public NodeScore getMin(NodeScore current) {
		 if(current.getLeft()==null) {
			 return current;
		 }else {
			 return getMin(current.getLeft());
		 }
	 }
	
	public void triggerDelete(String j) {
		delete(j, root);
	}
}
