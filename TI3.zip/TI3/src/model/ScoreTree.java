package model;

public class ScoreTree {
	
private NodeScore root;
	
	public void inOrder(NodeScore node) {
		if(node==null) {
			return;
		}
		
		inOrder(node.getLeft());
		System.out.println(node.getPlayer()+" "+node.getKey());
		inOrder(node.getRight());
	}
	
	public void triggerInOrder() {
		inOrder(root);
	}
	

	public void add(int score, String name) {
		if(root == null) {
			root= new NodeScore(score, name);
		}else {
			root.insert(score, name);
		}
		
	}
}
