package model;

import ui.LoginScreen;

public class BarThread extends Thread{
	
	private LoginScreen screen;

	public BarThread(LoginScreen screen) {
		this.screen = screen;
	}
	
	public void run() {
		int maxL=100;
		double c=0;
		try {
			for(int i=0;i<maxL;i++) {
				Thread.sleep(100);
				c+=0.01;
				screen.barChange(c);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
