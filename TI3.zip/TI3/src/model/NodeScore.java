package model;

import java.util.ArrayList;

public class NodeScore {

	private int key;
	private ArrayList<Player> value;
	
	public NodeScore(int key) {
		this.key = key;
		this.value = new ArrayList<>();
	}
	
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}
	public ArrayList<Player> getValue() {
		return value;
	}
	public void setValue(ArrayList<Player> value) {
		this.value = value;
	}
}
