package model;

import java.util.ArrayList;

public class NodeScore {

	private int score;
	private String player;
	
	private NodeScore left, right;
	
	public NodeScore(int key, String name) {
		this.score = key;
		this.player = name;
	}
	
	public void insert(int score, String name) {
		if(score>this.score) {
			if(this.left==null) {
				this.left=new NodeScore(score, name);
			}else {
				this.left.insert(score, name);
			}
		}else if(score<this.score) {
			if(this.right==null) {
				this.right=new NodeScore(score, name);
			}else {
				this.right.insert(score, name);
			}
		}
	}
	
	public int getKey() {
		return score;
	}
	public void setKey(int key) {
		this.score = key;
	}
	public String getPlayer() {
		return player;
	}
	public void setValue(String player) {
		this.player = player;
	}
	
	public NodeScore getLeft() {
		return left;
	}
	public NodeScore getRight() {
		return right;
	}
}
