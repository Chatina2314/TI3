package model;

public class playerList {
	
	private String user;
	private int score;
}
