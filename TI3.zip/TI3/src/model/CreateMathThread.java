package model;

import ui.MathChallenge;

public class CreateMathThread extends Thread{
	
	private MathChallenge math;

	public CreateMathThread(MathChallenge math) {
		this.math = math;
	}
	
	public void createMath() {
		int op =0;
		op=(int)(Math.random()*99)+1;
   
		System.out.println(op);
		math.createMath(op+ 1);
	}

}
